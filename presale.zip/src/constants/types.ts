export const SALE_TYPE = process.env.REACT_APP_SALE_TYPE || "1";
export const DEFAULT_PASSWORD = process.env.REACT_APP_DEFAULT_PASSWORD || "playerone";
console.log('SALE_TYPE:', SALE_TYPE)
