export const APP_VERSION = '1.4.5';
